<template>
    <div>
        <br>
        <center><h1>What should be here?</h1></center>
    </div>
</template>

<script>
    export default {
        name: "CreatePlaylist"
    }
</script>