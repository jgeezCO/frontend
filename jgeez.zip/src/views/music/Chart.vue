<template>
    <div>
        <h1>Chart</h1>
    </div>
</template>

<script>
    
    export default {
        name: 'Chart',
        components: {
            
        }
    }
</script>
