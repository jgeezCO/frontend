<template>
    <div class="creators_container">
        <center class="highlighter">
            <p class="highlighter_cap poppins">Creators’ Focus</p>
        </center>
        <h4 class="poppins" style="color:white;">
            Most Followed Creators <span class="gold-color" style="font-size: 20px;">JULY 2021</span>
        </h4>
        <div class="listing">
            <ul>
                <li class="left">
                    <div class="left">
                        <img class="himg" src="../static/uploads/img/80/1.png"> 
                    </div>
                    <div class="right">
                        <h4 class="noSpace poppins" style="color:white;">Linda Ikeji TV</h4>
                        <p class="noSpace poppins" style="color:white;font-size:13px;">
                            <b class="gold-color">200k</b> new fans
                        </p>
                        <a href="#" class="artist-follow">Subscribe</a>
                    </div>
                </li>
                
                <li class="left">
                    <div class="left">
                        <img class="himg" src="../static/uploads/img/80/1.png"> 
                    </div>
                    <div class="right">
                        <h4 class="noSpace poppins" style="color:white;">Linda Ikeji TV</h4>
                        <p class="noSpace poppins" style="color:white;font-size:13px;">
                            <b class="gold-color">200k</b> new fans
                        </p>
                        <a href="#" class="artist-follow">Subscribe</a>
                    </div>
                </li>

                <li class="left">
                    <div class="left">
                        <img class="himg" src="../static/uploads/img/80/1.png"> 
                    </div>
                    <div class="right">
                        <h4 class="noSpace poppins" style="color:white;">Linda Ikeji TV</h4>
                        <p class="noSpace poppins" style="color:white;font-size:13px;">
                            <b class="gold-color">200k</b> new fans
                        </p>
                        <a href="#" class="artist-follow">Subscribe</a>
                    </div>
                </li>

                <li class="left">
                    <div class="left">
                        <img class="himg" src="../static/uploads/img/80/1.png"> 
                    </div>

                    <div class="right">
                        <h4 class="noSpace poppins" style="color:white;">Linda Ikeji TV</h4>
                        <p class="noSpace poppins" style="color:white;font-size:13px;">
                            <b class="gold-color">200k</b> new fans
                        </p>
                        <a href="#" class="artist-follow">Subscribe</a>
                    </div>
                </li>

                <li class="left">
                    <div class="left">
                        <img class="himg" src="../static/uploads/img/80/1.png"> 
                    </div>
                    <div class="right">
                        <h4 class="noSpace poppins" style="color:white;">Linda Ikeji TV</h4>
                        <p class="noSpace poppins" style="color:white;font-size:13px;">
                            <b class="gold-color">200k</b> new fans
                        </p>
                        <a href="#" class="artist-follow">Subscribe</a>
                    </div>
                </li>
                
                <li class="left">
                    <div class="left">
                        <img class="himg" src="../static/uploads/img/80/1.png"> 
                    </div>
                    <div class="right">
                        <h4 class="noSpace poppins" style="color:white;">Linda Ikeji TV</h4>
                        <p class="noSpace poppins" style="color:white;font-size:13px;">
                            <b class="gold-color">200k</b> new fans
                        </p>
                        <a href="#" class="artist-follow">Subscribe</a>
                    </div>
                </li>
            </ul>
        </div>
        <div class="clear"></div>
    </div>
</template>

<script>
    export default {
        name: "Creator"
    }
</script>