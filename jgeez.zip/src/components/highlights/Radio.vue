<template>
    <div class="container_padding">
        <h2 style="color:white" class="poppins">
            Top Radio Stations &nbsp;
            <img src="../static/svg/radio.svg" style="position:relative;top:8px;">
        </h2>

        <div>
            
        </div>
    </div>
</template>

<script>
    export default{
        name: "RadioHighlight"
    }
</script>