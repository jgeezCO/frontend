<template>
    <div class="gist_section">
        <h2 class="poppins" style="color:white;font-weight:normal !important">
            Latest Gist
        </h2>

        <div class="gist_card_container">
            <div class="gist_card" style="background-image: url(../static/uploads/img/80/g1.png);">
                <h3 class="poppins noSpace">New and Improved IPhone, Buy OR NOT!</h3>
                <p class="poppins noSpace" style="font-weight:normal;color:#f1f1f1;font-size:13px;">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quam tincidunt tincidunt risus etiam sed volutpat aliquam orci quis. Aliquet enim eget proin hendrerit. Lacinia in arcu ipsum at sapien venenatis amet tellus.</p>
                <div class="gist_action poppins">
                    <div class="left">
                        <img src="../static/svg/eye.svg"> <span class="poppins">2.4k</span> &nbsp;&nbsp;
                        <img src="../static/svg/heart.svg"> <span class="poppins">1.2k</span>    
                    </div>
                    <div class="right">
                        <a href="#" style="font-size:13px;padding: 8px 12px;color:white;background-color:#DB1A1A;border-radius:5.62px;">Read more</a>
                    </div>
                    <div class="clear"></div>
                </div>
            </div>

            <div class="gist_card" style="background-image: url(../static/uploads/img/80/g1.png);">
                <h3 class="poppins noSpace">New and Improved IPhone, Buy OR NOT!</h3>
                <p class="poppins noSpace" style="font-weight:normal;color:#f1f1f1;font-size:13px;">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quam tincidunt tincidunt risus etiam sed volutpat aliquam orci quis. Aliquet enim eget proin hendrerit. Lacinia in arcu ipsum at sapien venenatis amet tellus.</p>
                <div class="gist_action poppins">
                    <div class="left">
                        <img src="../static/svg/eye.svg"> <span class="poppins">2.4k</span> &nbsp;&nbsp;
                        <img src="../static/svg/heart.svg"> <span class="poppins">1.2k</span>    
                    </div>
                    <div class="right">
                        <a href="#" style="font-size:13px;padding: 8px 12px;color:white;background-color:#DB1A1A;border-radius:5.62px;">Read more</a>
                    </div>
                    <div class="clear"></div>
                </div>
            </div>

            <div class="gist_card" style="background-image: url(../static/uploads/img/80/g1.png);">
                <h3 class="poppins noSpace">New and Improved IPhone, Buy OR NOT!</h3>
                <p class="poppins noSpace" style="font-weight:normal;color:#f1f1f1;font-size:13px;">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quam tincidunt tincidunt risus etiam sed volutpat aliquam orci quis. Aliquet enim eget proin hendrerit. Lacinia in arcu ipsum at sapien venenatis amet tellus.</p>
                <div class="gist_action poppins">
                    <div class="left">
                        <img src="../static/svg/eye.svg"> <span class="poppins">2.4k</span> &nbsp;&nbsp;
                        <img src="../static/svg/heart.svg"> <span class="poppins">1.2k</span>    
                    </div>
                    <div class="right">
                        <a href="#" style="font-size:13px;padding: 8px 12px;color:white;background-color:#DB1A1A;border-radius:5.62px;">Read more</a>
                    </div>
                    <div class="clear"></div>
                </div>
            </div>

            <div class="gist_card" style="background-image: url(../static/uploads/img/80/g1.png);">
                <h3 class="poppins noSpace">New and Improved IPhone, Buy OR NOT!</h3>
                <p class="poppins noSpace" style="font-weight:normal;color:#f1f1f1;font-size:13px;">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Quam tincidunt tincidunt risus etiam sed volutpat aliquam orci quis. Aliquet enim eget proin hendrerit. Lacinia in arcu ipsum at sapien venenatis amet tellus.</p>
                <div class="gist_action poppins">
                    <div class="left">
                        <img src="../static/svg/eye.svg"> <span class="poppins">2.4k</span> &nbsp;&nbsp;
                        <img src="../static/svg/heart.svg"> <span class="poppins">1.2k</span>    
                    </div>
                    <div class="right">
                        <a href="#" style="font-size:13px;padding: 8px 12px;color:white;background-color:#DB1A1A;border-radius:5.62px;">Read more</a>
                    </div>
                    <div class="clear"></div>
                </div>
            </div>

            <div class="clear"></div>
        </div>
    </div>
</template>

<script>
    export default {
        name: "GistHighlight",
        props: {
            Gists: Array
        }
    }
</script>